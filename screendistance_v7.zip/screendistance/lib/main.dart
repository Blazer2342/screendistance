import 'package:camera_android/camera_android.dart';
import 'package:camera_platform_interface/camera_platform_interface.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import 'home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // CameraX yerine eski/klasik Camera2 tabanli implementasyonu zorla
  // kullaniyoruz. CameraX surumu, arka plan servisi (Activity'siz isolate)
  // icinde izin kontrolu yaparken hata veriyordu.
  CameraPlatform.instance = AndroidCamera();

  FlutterForegroundTask.initCommunicationPort();
  runApp(const ScreenDistanceApp());
}

class ScreenDistanceApp extends StatelessWidget {
  const ScreenDistanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ScreenDistance',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const HomeScreen(),
    );
  }
}
