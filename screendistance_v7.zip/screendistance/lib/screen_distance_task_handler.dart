import 'dart:async';
import 'dart:isolate';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:camera_android/camera_android.dart';
import 'package:camera_platform_interface/camera_platform_interface.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:screen_brightness/screen_brightness.dart';

import 'distance_estimator.dart';
import 'settings_service.dart';

/// Ana isolate'e (UI) anlik mesafe bilgisini gondermek icin port adi
const String distancePortName = 'screendistance_port';

/// flutter_foreground_task kutuphanesinin gerektirdigi giris noktasi.
/// Bu fonksiyon ayri bir isolate'de calisir.
@pragma('vm:entry-point')
void startCallback() {
  // Bu isolate ayri oldugu icin kamera implementasyonunu burada da
  // ayarlamamiz gerekiyor (ana isolate'teki ayar buraya tasinmaz).
  CameraPlatform.instance = AndroidCamera();
  FlutterForegroundTask.setTaskHandler(ScreenDistanceTaskHandler());
}

class ScreenDistanceTaskHandler extends TaskHandler {
  CameraController? _cameraController;
  FaceDetector? _faceDetector;
  final DistanceEstimator _estimator = DistanceEstimator();
  final SettingsService _settings = SettingsService();

  double _thresholdCm = SettingsService.defaultThresholdCm;
  double _dimLevel = SettingsService.defaultDimLevel;
  double? _originalBrightness;
  bool _isDimmed = false;
  bool _isProcessingFrame = false;

  SendPort? _uiSendPort;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    _thresholdCm = await _settings.getThresholdCm();
    _dimLevel = await _settings.getDimLevel();

    final savedCalibration = await _settings.getCalibrationFactor();
    if (savedCalibration != null) {
      _estimator.calibrationFactor = savedCalibration;
    }

    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.fast,
        enableLandmarks: true,
        enableTracking: false,
        // Dogrulugu ihtiyacimiz kadar tutup CPU/pil yukunu azaltiyoruz
        minFaceSize: 0.15,
      ),
    );

    try {
      _originalBrightness = await ScreenBrightness().current;
    } catch (_) {
      _originalBrightness = 0.5;
    }

    await _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      final frontCamera = cameras.firstWhere(
        (cam) => cam.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      // Dusuk cozunurluk = daha az pil/CPU. Yuz tespiti icin bu fazlasiyla yeterli.
      _cameraController = CameraController(
        frontCamera,
        ResolutionPreset.low,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.nv21,
      );

      await _cameraController!.initialize();

      await _cameraController!.startImageStream(_processCameraImage);
    } catch (e) {
      FlutterForegroundTask.updateService(
        notificationTitle: 'ScreenDistance',
        notificationText: 'Kamera baslatilamadi: $e',
      );
    }
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (_isProcessingFrame || _faceDetector == null) return;
    _isProcessingFrame = true;

    try {
      final inputImage = _convertCameraImage(image);
      if (inputImage == null) {
        _isProcessingFrame = false;
        return;
      }

      final faces = await _faceDetector!.processImage(inputImage);

      if (faces.isNotEmpty) {
        final distance = _estimator.estimateDistanceCm(faces.first, image.width);
        if (distance != null) {
          await _handleDistanceReading(distance);
        }
      } else {
        // Yuz bulunamadiginda (kullanici kameradan tamamen ciktiysa)
        // ekrani kararmis durumda BIRAKMIYORUZ - guvenlik icin normale donduruyoruz.
        await _restoreBrightnessIfNeeded();
      }
    } catch (_) {
      // Tek bir frame hatasi servisi durdurmamali
    } finally {
      _isProcessingFrame = false;
    }
  }

  Future<void> _handleDistanceReading(double distanceCm) async {
    // UI acikken anlik deger gostermek icin gonder
    FlutterForegroundTask.sendDataToMain({
      'type': 'distance',
      'value': distanceCm,
    });

    if (distanceCm < _thresholdCm && !_isDimmed) {
      await _dimScreen();
    } else if (distanceCm >= _thresholdCm && _isDimmed) {
      await _restoreBrightnessIfNeeded();
    }

    FlutterForegroundTask.updateService(
      notificationTitle: 'ScreenDistance Aktif',
      notificationText:
          'Mesafe: ${distanceCm.toStringAsFixed(1)} cm  ${_isDimmed ? "(Kararti ldi)" : ""}',
    );
  }

  Future<void> _dimScreen() async {
    try {
      _originalBrightness ??= await ScreenBrightness().current;
      await ScreenBrightness().setScreenBrightness(_dimLevel);
      _isDimmed = true;
    } catch (_) {}
  }

  Future<void> _restoreBrightnessIfNeeded() async {
    if (!_isDimmed) return;
    try {
      await ScreenBrightness().setScreenBrightness(_originalBrightness ?? 0.5);
      _isDimmed = false;
    } catch (_) {}
  }

  InputImage? _convertCameraImage(CameraImage image) {
    try {
      final bytes = image.planes.first.bytes;
      final size = Size(image.width.toDouble(), image.height.toDouble());

      return InputImage.fromBytes(
        bytes: bytes,
        metadata: InputImageMetadata(
          size: size,
          rotation: InputImageRotation.rotation270deg,
          format: InputImageFormat.nv21,
          bytesPerRow: image.planes.first.bytesPerRow,
        ),
      );
    } catch (_) {
      return null;
    }
  }

  @override
  void onReceiveData(Object data) {
    // UI tarafindan eslik mesafesi gibi ayarlar canli guncellenebilir
    if (data is Map) {
      if (data['type'] == 'updateThreshold') {
        _thresholdCm = data['value'] as double;
      } else if (data['type'] == 'updateDimLevel') {
        _dimLevel = data['value'] as double;
      } else if (data['type'] == 'calibrate') {
        // Kalibrasyon UI tarafinda hesaplanip buraya yeni katsayi gonderilir
        _estimator.calibrationFactor = data['value'] as double;
      }
    }
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    await _restoreBrightnessIfNeeded();
    await _cameraController?.stopImageStream();
    await _cameraController?.dispose();
    await _faceDetector?.close();
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    // Periyodik islem gerekmiyor, goruntu akisi (image stream) zaten surekli calisiyor.
  }

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }

  @override
  void onNotificationDismissed() {}
}
