import 'dart:async';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:screen_brightness/screen_brightness.dart';

import 'distance_estimator.dart';

/// Kamerayi ve yuz tespitini ANA ISOLATE'DE (UI ile ayni isolate) calistiran
/// servis. Bu sayede camera plugin'i native tarafa duzgun baglanir.
///
/// flutter_foreground_task, bu servisin "arka planda da oldurulmemesini"
/// saglamak icin sadece bir bildirim/kabuk olarak kullanilir - kameranin
/// kendisi bu sinif icinde, normal Flutter isolate'inde calisir.
class DistanceMonitorService {
  CameraController? _cameraController;
  FaceDetector? _faceDetector;
  final DistanceEstimator estimator = DistanceEstimator();

  double thresholdCm = 30.0;
  double dimLevel = 0.05;
  double? _originalBrightness;
  bool _isDimmed = false;
  bool _isProcessingFrame = false;
  bool _isRunning = false;

  final _distanceController = StreamController<double>.broadcast();
  final _dimStateController = StreamController<bool>.broadcast();

  /// Anlik mesafe okumalarini dinlemek icin
  Stream<double> get distanceStream => _distanceController.stream;

  /// Ekranin kararip kararmadigini dinlemek icin
  Stream<bool> get dimStateStream => _dimStateController.stream;

  bool get isRunning => _isRunning;
  bool get isDimmed => _isDimmed;

  Future<void> start() async {
    if (_isRunning) return;

    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.fast,
        enableLandmarks: true,
        enableTracking: false,
        minFaceSize: 0.15,
      ),
    );

    try {
      _originalBrightness = await ScreenBrightness().current;
    } catch (_) {
      _originalBrightness = 0.5;
    }

    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
      (cam) => cam.lensDirection == CameraLensDirection.front,
      orElse: () => cameras.first,
    );

    _cameraController = CameraController(
      frontCamera,
      ResolutionPreset.low,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.nv21,
    );

    await _cameraController!.initialize();
    await _cameraController!.startImageStream(_processCameraImage);

    _isRunning = true;
  }

  Future<void> stop() async {
    if (!_isRunning) return;
    await _restoreBrightnessIfNeeded();
    await _cameraController?.stopImageStream();
    await _cameraController?.dispose();
    _cameraController = null;
    await _faceDetector?.close();
    _faceDetector = null;
    _isRunning = false;
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (_isProcessingFrame || _faceDetector == null) return;
    _isProcessingFrame = true;

    try {
      final inputImage = _convertCameraImage(image);
      if (inputImage == null) {
        _isProcessingFrame = false;
        return;
      }

      final faces = await _faceDetector!.processImage(inputImage);

      if (faces.isNotEmpty) {
        final distance =
            estimator.estimateDistanceCm(faces.first, image.width);
        if (distance != null) {
          await _handleDistanceReading(distance);
        }
      } else {
        await _restoreBrightnessIfNeeded();
      }
    } catch (_) {
      // Tek bir frame hatasi servisi durdurmamali
    } finally {
      _isProcessingFrame = false;
    }
  }

  Future<void> _handleDistanceReading(double distanceCm) async {
    _distanceController.add(distanceCm);

    if (distanceCm < thresholdCm && !_isDimmed) {
      await _dimScreen();
    } else if (distanceCm >= thresholdCm && _isDimmed) {
      await _restoreBrightnessIfNeeded();
    }
  }

  Future<void> _dimScreen() async {
    try {
      _originalBrightness ??= await ScreenBrightness().current;
      await ScreenBrightness().setScreenBrightness(dimLevel);
      _isDimmed = true;
      _dimStateController.add(true);
    } catch (_) {}
  }

  Future<void> _restoreBrightnessIfNeeded() async {
    if (!_isDimmed) return;
    try {
      await ScreenBrightness().setScreenBrightness(_originalBrightness ?? 0.5);
      _isDimmed = false;
      _dimStateController.add(false);
    } catch (_) {}
  }

  InputImage? _convertCameraImage(CameraImage image) {
    try {
      final bytes = image.planes.first.bytes;
      final size = Size(image.width.toDouble(), image.height.toDouble());

      return InputImage.fromBytes(
        bytes: bytes,
        metadata: InputImageMetadata(
          size: size,
          rotation: InputImageRotation.rotation270deg,
          format: InputImageFormat.nv21,
          bytesPerRow: image.planes.first.bytesPerRow,
        ),
      );
    } catch (_) {
      return null;
    }
  }

  void dispose() {
    _distanceController.close();
    _dimStateController.close();
  }
}
