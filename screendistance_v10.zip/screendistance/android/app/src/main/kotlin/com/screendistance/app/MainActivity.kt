package com.screendistance.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
