# ScreenDistance

Göz sağlığı için ekran-yüz mesafe ölçer. Ön kamera ile yüz tespiti yapar,
belirlenen eşik mesafenin altına inildiğinde ekranı karartır, kullanıcı
uzaklaştığında eski parlaklığa döner.

## İçindekiler
- Nasıl çalışır?
- GitHub Actions ile APK alma (kurulum gerektirmez)
- Kalibrasyon neden gerekli?
- Bilinen sınırlamalar
- Play Store'a (AAB) geçiş

---

## Nasıl çalışır?

1. Ön kamera düşük çözünürlükte (pil tasarrufu için) görüntü akışı başlatır.
2. Google ML Kit, her karede yüzü ve göz noktalarını (landmark) tespit eder.
3. Gözler arası piksel mesafesinden, ortalama insan göz-arası mesafesi (6.3 cm)
   referans alınarak ekrana olan mesafe **tahmin** edilir.
4. Mesafe, ayarlanan eşiğin (varsayılan 30 cm) altına inerse ekran parlaklığı
   düşürülür. Kullanıcı uzaklaşınca eski parlaklığa döner.
5. Tüm bu işlem bir **foreground service** (ön planda bildirim gösteren arka
   plan servisi) içinde çalışır, böylece uygulama ekranı kapalı olsa da
   (Android'de) çalışmaya devam eder. Kullanıcı ana ekrandan istediği zaman
   durdurabilir.

> Not: Bu bir tıbbi cihaz değildir, genel göz sağlığı alışkanlığı
> oluşturmaya yardımcı bir araçtır.

---

## GitHub Actions ile APK Alma (bilgisayarına hiçbir şey kurmadan)

Bu en kolay yol — Flutter'ı bilgisayarına kurmana gerek yok.

### 1. GitHub hesabı aç (varsa atla)
https://github.com adresinden ücretsiz hesap oluştur.

### 2. Yeni bir repository (depo) oluştur
- GitHub'da sağ üstten **+ → New repository**
- İsim: `screendistance` (istediğin ismi verebilirsin)
- **Public** veya **Private** seçebilirsin, ikisi de Actions'ı ücretsiz çalıştırır
- "Create repository" de

### 3. Bu klasördeki tüm dosyaları o repo'ya yükle
En kolay yol GitHub web arayüzünden:
- Oluşturduğun repo sayfasında **"uploading an existing file"** linkine tıkla
- Bu projedeki **tüm dosya ve klasörleri** (pubspec.yaml, lib/, android/, .github/ dahil)
  sürükle-bırak ile yükle
- Alt kısımda "Commit changes" de

Ya da git komut satırı biliyorsan:
```bash
cd screendistance
git init
git add .
git commit -m "ilk surum"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/screendistance.git
git push -u origin main
```

### 4. Derlemenin otomatik başlamasını izle
- Repo sayfanda üstteki **"Actions"** sekmesine tıkla
- "Build APK" adında bir workflow çalışıyor olacak (yaklaşık 5-8 dakika sürer)
- Yeşil tik (✓) görünce tamamlanmış demektir

### 5. APK'yı indir
- Tamamlanan workflow'a tıkla
- Sayfanın altında **"Artifacts"** bölümünde:
  - `screendistance-apk` → bu senin APK dosyan (zip içinde, açınca `app-release.apk` çıkar)
  - `screendistance-aab` → ileride Play Store'a yüklemek istediğinde kullanacağın AAB dosyası
- Zip'i indir, içinden `.apk` dosyasını çıkar, telefonuna aktarıp kur
  (Android "bilinmeyen kaynaklardan yükleme" iznine onay vermen gerekebilir)

**Önemli:** Kod ne zaman değişirse (ister sen değiştir ister ben sana yeni
kod versem), `git push` yaptığında veya dosyaları yeniden yüklediğinde
Actions otomatik olarak yeniden derler. Manuel tekrar çalıştırmak istersen
Actions sekmesinde **"Run workflow"** butonunu da kullanabilirsin.

---

## Kalibrasyon neden gerekli?

Telefonların ön kamera lensleri (odak uzaklığı, görüş açısı) modelden modele
farklılık gösterir. Uygulama varsayılan bir katsayıyla başlar ama gerçek
kullanımda doğruluk için:

1. Uygulamayı aç → **"Mesafe Ölçümünü Kalibre Et"** butonuna bas
2. Bir cetvel/şerit metre ile telefonu yüzünden bilinen bir mesafede tut
   (örn. tam 30 cm)
3. Ekrandaki kaydırıcıyı o mesafeye ayarla (varsayılan 30 cm zaten seçili)
4. Yüzün tespit edildiğini gördüğünde **"Kalibre Et"** de

Bu kalibrasyon cihazda saklanır, tekrar yapmana gerek kalmaz (telefon
değiştirirsen veya doğruluk bozulursa tekrar yapabilirsin).

---

## Bilinen sınırlamalar

- **Bu bir gerçek "derinlik sensörü" değildir.** iPhone'daki TrueDepth gibi
  donanım Android'de yaygın değil. Mesafe, yüz/göz boyutundan **matematiksel
  tahmin** ile hesaplanır. Gözlük takmak, kafa açısı, ışık koşulları doğruluğu
  ±3-5 cm kadar etkileyebilir — bu genel kullanım için yeterlidir ama tıbbi
  hassasiyette değildir.
- **Yalnızca Android için APK üretiyoruz.** Kod Flutter ile yazıldığı için
  ileride iOS desteği eklenebilir, ama iOS'ta arka planda kamera kullanımı
  Apple tarafından kısıtlandığından farklı bir yaklaşım gerekir (sadece
  uygulama ön plandayken çalışma gibi).
- **Pil tüketimi:** Kamera sürekli açık olduğu için (senin tercihin doğrultusunda
  doğruluk öncelikli ayarlandı) normal kullanıma göre fark edilir ölçüde pil
  harcar. Düşük çözünürlük ve "fast" tespit modu kullanılarak bu olabildiğince
  azaltılmıştır.
- **APK şu an "debug" imzasıyla derleniyor.** Kendi telefonunda test etmek
  için sorun değil. Play Store'a yüklemeden önce kendi imzanı (keystore)
  oluşturup kullanman gerekir (aşağıya bak).

---

## Play Store'a (AAB) geçiş

Workflow zaten her derlemede bir `.aab` dosyası da üretiyor. Ancak Play
Store'a yüklemeden önce yapman gerekenler:

1. **Kendi imza anahtarını (keystore) oluştur:**
   ```bash
   keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA \
     -keysize 2048 -validity 10000 -alias upload
   ```
2. `android/key.properties` dosyası oluştur (bu dosya `.gitignore`'da, asla
   GitHub'a yüklenmemeli):
   ```
   storePassword=<şifren>
   keyPassword=<şifren>
   keyAlias=upload
   storeFile=../upload-keystore.jks
   ```
3. `android/app/build.gradle` içindeki `signingConfig = signingConfigs.debug`
   satırını kendi keystore'unu kullanacak şekilde güncellemen gerekir
   (bu noktaya geldiğinde bana söyle, o adımı da senin için yaparım).
4. `applicationId` değerini (`com.screendistance.app`) Play Console'da
   kayıtlı kendi paket adınla eşleştir — bu değer yayından sonra **değiştirilemez**.

Bu noktaya gelince haber ver, imzalama adımlarını birlikte tamamlarız.
