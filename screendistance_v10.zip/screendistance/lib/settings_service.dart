import 'package:shared_preferences/shared_preferences.dart';

/// Uygulama ayarlarini cihazda kalici olarak saklar (SharedPreferences).
class SettingsService {
  static const _keyThresholdCm = 'threshold_cm';
  static const _keyCalibrationFactor = 'calibration_factor';
  static const _keyServiceEnabled = 'service_enabled';
  static const _keyDimLevel = 'dim_level';

  // Varsayilan: 30 cm altina inince ekran kararsin (genel goz sagligi tavsiyesi)
  static const double defaultThresholdCm = 30.0;

  // Ekran ne kadar karasin (0.0 - 1.0 arasi parlaklik degeri, hedef parlaklik)
  static const double defaultDimLevel = 0.05;

  Future<double> getThresholdCm() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyThresholdCm) ?? defaultThresholdCm;
  }

  Future<void> setThresholdCm(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyThresholdCm, value);
  }

  Future<double?> getCalibrationFactor() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyCalibrationFactor);
  }

  Future<void> setCalibrationFactor(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyCalibrationFactor, value);
  }

  Future<bool> isServiceEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyServiceEnabled) ?? false;
  }

  Future<void> setServiceEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyServiceEnabled, value);
  }

  Future<double> getDimLevel() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyDimLevel) ?? defaultDimLevel;
  }

  Future<void> setDimLevel(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyDimLevel, value);
  }
}
