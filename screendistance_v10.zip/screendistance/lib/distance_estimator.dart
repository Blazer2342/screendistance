import 'dart:math';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

/// Yuz tespiti sonuclarindan ekran-yuz mesafesini santimetre olarak tahmin eder.
///
/// Mantik: Insan gozleri arasi ortalama mesafe ~6.3 cm'dir (interpupillary distance).
/// Kamera goruntusunde gozler arasindaki piksel mesafesi, yuz kameraya
/// yaklastikca buyur, uzaklastikca kucculur. Bu iliski ters orantilidir:
///
///   mesafe_cm = (gercek_goz_arasi_cm * odak_uzakligi_piksel) / goz_arasi_piksel
///
/// Telefon modeline gore odak uzakligi degisir, bu yuzden basit bir kalibrasyon
/// katsayisi kullaniyoruz. Bu katsayi ayarlar ekraninda kullanici tarafindan
/// kalibre edilebilir (bilinen bir mesafede dur, "kalibre et" de).
class DistanceEstimator {
  // Ortalama insan gozbebekleri arasi mesafe (cm) - yetiskinler icin tipik deger
  static const double averageEyeDistanceCm = 6.3;

  // Varsayilan kalibrasyon katsayisi (odak uzakligi ~piksel cinsinden).
  // Bu deger ilk kalibrasyonda kullanicinin cihazina gore guncellenir.
  // Varsayilan: ortalama bir telefonun on kamerasi icin yaklasik deger.
  double calibrationFactor = 1000.0;

  /// Son N olcumun ortalamasini alarak titremeyi (jitter) azaltmak icin
  final List<double> _recentReadings = [];
  static const int _smoothingWindow = 5;

  /// Tespit edilen yuzden mesafeyi tahmin eder.
  /// Geri donen deger santimetre cinsindendir. Yuz bulunamazsa null doner.
  double? estimateDistanceCm(Face face, int imageWidth) {
    final leftEye = face.landmarks[FaceLandmarkType.leftEye];
    final rightEye = face.landmarks[FaceLandmarkType.rightEye];

    double eyeDistancePx;

    if (leftEye != null && rightEye != null) {
      final dx = (leftEye.position.x - rightEye.position.x).toDouble();
      final dy = (leftEye.position.y - rightEye.position.y).toDouble();
      eyeDistancePx = sqrt(dx * dx + dy * dy);
    } else {
      // Goz landmark'lari yoksa, yuz kutusunun genisligine gore kaba bir tahmin yap.
      // Ortalama bir yuzde goz arasi mesafe, yuz genisliginin ~%45'i kadardir.
      eyeDistancePx = face.boundingBox.width * 0.45;
    }

    if (eyeDistancePx <= 0) return null;

    final rawDistance =
        (averageEyeDistanceCm * calibrationFactor) / eyeDistancePx;

    return _smooth(rawDistance);
  }

  double _smooth(double newReading) {
    _recentReadings.add(newReading);
    if (_recentReadings.length > _smoothingWindow) {
      _recentReadings.removeAt(0);
    }
    final sum = _recentReadings.fold<double>(0, (a, b) => a + b);
    return sum / _recentReadings.length;
  }

  /// Kullanici bilinen bir mesafede dururken (orn. 30cm) cagrilir.
  /// Olculen ham goz-arasi-piksel degerine gore katsayiyi yeniden hesaplar.
  void calibrate(Face face, double knownDistanceCm) {
    final leftEye = face.landmarks[FaceLandmarkType.leftEye];
    final rightEye = face.landmarks[FaceLandmarkType.rightEye];

    double eyeDistancePx;
    if (leftEye != null && rightEye != null) {
      final dx = (leftEye.position.x - rightEye.position.x).toDouble();
      final dy = (leftEye.position.y - rightEye.position.y).toDouble();
      eyeDistancePx = sqrt(dx * dx + dy * dy);
    } else {
      eyeDistancePx = face.boundingBox.width * 0.45;
    }

    if (eyeDistancePx <= 0) return;

    calibrationFactor = (eyeDistancePx * knownDistanceCm) / averageEyeDistanceCm;
    _recentReadings.clear();
  }

  void reset() {
    _recentReadings.clear();
  }
}
