import 'package:flutter_foreground_task/flutter_foreground_task.dart';

/// flutter_foreground_task kutuphanesinin gerektirdigi giris noktasi.
/// Bu fonksiyon ayri bir isolate'de calisir.
///
/// ONEMLI: Kamera ve mesafe hesaplama burada YAPILMIYOR. Bu servis sadece
/// Android'in uygulamayi arka planda "oldurmesini" engelleyen bir bildirim
/// kabugu. Gercek kamera/mesafe islemleri ana isolate'de (DistanceMonitorService
/// icinde) calisiyor, cunku camera plugin'i arka plan isolate'inde native
/// tarafa baglanamiyor (bilinen bir Flutter kisitlamasi).
@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(_KeepAliveTaskHandler());
}

class _KeepAliveTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {
    // Sadece bildirimi canli tutmak icin periyodik tetiklenir.
    // Gercek is ana isolate'de yapiliyor.
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {}

  @override
  void onReceiveData(Object data) {}

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }

  @override
  void onNotificationDismissed() {}
}
