import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';

import 'settings_service.dart';
import 'screen_distance_task_handler.dart';
import 'distance_monitor_service.dart';
import 'calibration_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final SettingsService _settings = SettingsService();
  final DistanceMonitorService _monitor = DistanceMonitorService();

  bool _isRunning = false;
  double _thresholdCm = SettingsService.defaultThresholdCm;
  double? _currentDistance;
  bool _isDimmed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadState();

    _monitor.distanceStream.listen((distance) {
      if (mounted) {
        setState(() => _currentDistance = distance);
      }
    });

    _monitor.dimStateStream.listen((dimmed) {
      if (mounted) {
        setState(() => _isDimmed = dimmed);
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _monitor.dispose();
    super.dispose();
  }

  Future<void> _loadState() async {
    final threshold = await _settings.getThresholdCm();
    final savedCalibration = await _settings.getCalibrationFactor();
    setState(() {
      _thresholdCm = threshold;
      _monitor.thresholdCm = threshold;
      if (savedCalibration != null) {
        _monitor.estimator.calibrationFactor = savedCalibration;
      }
    });
  }

  Future<bool> _requestPermissions() async {
    final cameraStatus = await Permission.camera.request();
    if (!cameraStatus.isGranted) return false;

    if (await FlutterForegroundTask.checkNotificationPermission() !=
        NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }

    return true;
  }

  void _initForegroundTask() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'screendistance_channel',
        channelName: 'ScreenDistance Servisi',
        channelDescription: 'Ekran mesafesi izleniyor.',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
  }

  Future<void> _toggleService() async {
    if (_isRunning) {
      await _monitor.stop();
      await FlutterForegroundTask.stopService();
      await _settings.setServiceEnabled(false);
      setState(() {
        _isRunning = false;
        _currentDistance = null;
        _isDimmed = false;
      });
      return;
    }

    final granted = await _requestPermissions();
    if (!granted) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Kamera izni olmadan servis calismaz.'),
        ),
      );
      return;
    }

    try {
      // Once kamerayi ANA ISOLATE'DE baslat (bu yuzden burada calisiyor,
      // arka plan isolate'inde degil - camera plugin sorunu boylece cozuluyor).
      _monitor.thresholdCm = _thresholdCm;
      await _monitor.start();

      // Sonra arka planda "canli tutma" bildirimini baslat. Bu, Android'in
      // uygulamayi oldurmesini engeller; kameranin kendisiyle ilgilenmez.
      _initForegroundTask();
      await FlutterForegroundTask.startService(
        notificationTitle: 'ScreenDistance Aktif',
        notificationText: 'Mesafe izleniyor...',
        callback: startCallback,
      );

      await _settings.setServiceEnabled(true);
      setState(() => _isRunning = true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kamera baslatilamadi: $e')),
      );
    }
  }

  Future<void> _updateThreshold(double value) async {
    setState(() => _thresholdCm = value);
    _monitor.thresholdCm = value;
    await _settings.setThresholdCm(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ScreenDistance'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildStatusCard(),
              const SizedBox(height: 24),
              _buildDistanceDisplay(),
              const SizedBox(height: 32),
              _buildThresholdSlider(),
              const SizedBox(height: 24),
              _buildStartStopButton(),
              const SizedBox(height: 12),
              _buildCalibrateButton(),
              const Spacer(),
              _buildInfoText(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    return Card(
      color: _isRunning
          ? Colors.green.withOpacity(0.1)
          : Colors.grey.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(
              _isRunning ? Icons.visibility : Icons.visibility_off,
              color: _isRunning ? Colors.green : Colors.grey,
            ),
            const SizedBox(width: 12),
            Text(
              _isRunning ? 'Servis Aktif' : 'Servis Kapali',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDistanceDisplay() {
    if (!_isRunning) {
      return const SizedBox(height: 80);
    }
    final distance = _currentDistance;
    final isClose = _isDimmed;

    return Container(
      height: 100,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: isClose
            ? Colors.red.withOpacity(0.1)
            : Colors.blue.withOpacity(0.08),
      ),
      child: Text(
        distance != null
            ? '${distance.toStringAsFixed(1)} cm'
            : 'Olcum bekleniyor...',
        style: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: isClose ? Colors.red : Colors.blue,
        ),
      ),
    );
  }

  Widget _buildThresholdSlider() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Esik mesafe: ${_thresholdCm.toStringAsFixed(0)} cm',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        const Text(
          'Bu mesafenin altina indiginde ekran kararir',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        Slider(
          value: _thresholdCm,
          min: 15,
          max: 60,
          divisions: 45,
          label: '${_thresholdCm.toStringAsFixed(0)} cm',
          onChanged: _updateThreshold,
        ),
      ],
    );
  }

  Widget _buildStartStopButton() {
    return ElevatedButton.icon(
      onPressed: _toggleService,
      icon: Icon(_isRunning ? Icons.stop : Icons.play_arrow),
      label: Text(_isRunning ? 'Servisi Durdur' : 'Servisi Baslat'),
      style: ElevatedButton.styleFrom(
        backgroundColor: _isRunning ? Colors.red : Colors.green,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
      ),
    );
  }

  Widget _buildCalibrateButton() {
    return OutlinedButton.icon(
      onPressed: () async {
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const CalibrationScreen()),
        );
      },
      icon: const Icon(Icons.tune),
      label: const Text('Mesafe Olcumunu Kalibre Et'),
    );
  }

  Widget _buildInfoText() {
    return const Text(
      'Onerilen okuma/ekran mesafesi en az 30-40 cm\'dir. '
      'Daha kesin sonuc icin kalibrasyon yapmaniz onerilir.',
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: 12, color: Colors.grey),
    );
  }
}
