import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import 'distance_estimator.dart';
import 'settings_service.dart';

/// Kullanicinin bilinen bir mesafede (orn. bir cetvel ile 30cm) durup
/// uygulamayi kalibre etmesini saglayan ekran.
class CalibrationScreen extends StatefulWidget {
  const CalibrationScreen({super.key});

  @override
  State<CalibrationScreen> createState() => _CalibrationScreenState();
}

class _CalibrationScreenState extends State<CalibrationScreen> {
  CameraController? _controller;
  FaceDetector? _faceDetector;
  final DistanceEstimator _estimator = DistanceEstimator();
  final SettingsService _settings = SettingsService();

  double _knownDistanceCm = 30.0;
  bool _isReady = false;
  bool _isCalibrating = false;
  String _status = 'Kamera baslatiliyor...';
  Face? _lastDetectedFace;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      final frontCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _controller = CameraController(
        frontCamera,
        ResolutionPreset.low,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.nv21,
      );

      _faceDetector = FaceDetector(
        options: FaceDetectorOptions(
          performanceMode: FaceDetectorMode.fast,
          enableLandmarks: true,
        ),
      );

      await _controller!.initialize();
      await _controller!.startImageStream(_onImage);

      setState(() {
        _isReady = true;
        _status = 'Yuzunuz aranıyor...';
      });
    } catch (e) {
      setState(() => _status = 'Kamera hatasi: $e');
    }
  }

  bool _processing = false;

  Future<void> _onImage(CameraImage image) async {
    if (_processing || _faceDetector == null) return;
    _processing = true;
    try {
      final inputImage = InputImage.fromBytes(
        bytes: image.planes.first.bytes,
        metadata: InputImageMetadata(
          size: Size(image.width.toDouble(), image.height.toDouble()),
          rotation: InputImageRotation.rotation270deg,
          format: InputImageFormat.nv21,
          bytesPerRow: image.planes.first.bytesPerRow,
        ),
      );

      final faces = await _faceDetector!.processImage(inputImage);
      if (faces.isNotEmpty) {
        _lastDetectedFace = faces.first;
        if (mounted) {
          setState(() => _status = 'Yuz tespit edildi. Hazir oldugunuzda kalibre edin.');
        }
      } else {
        _lastDetectedFace = null;
        if (mounted) {
          setState(() => _status = 'Yuzunuz aranıyor...');
        }
      }
    } catch (_) {
    } finally {
      _processing = false;
    }
  }

  Future<void> _calibrate() async {
    final face = _lastDetectedFace;
    if (face == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Once yuzunuzun tespit edilmesini bekleyin.')),
      );
      return;
    }

    setState(() => _isCalibrating = true);

    _estimator.calibrate(face, _knownDistanceCm);
    await _settings.setCalibrationFactor(_estimator.calibrationFactor);

    // Eger servis calisiyorsa yeni katsayiyi anlik gonder
    if (await FlutterForegroundTask.isRunningService) {
      FlutterForegroundTask.sendDataToTask({
        'type': 'calibrate',
        'value': _estimator.calibrationFactor,
      });
    }

    setState(() => _isCalibrating = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kalibrasyon tamamlandi!')),
      );
      Navigator.of(context).pop();
    }
  }

  @override
  void dispose() {
    _controller?.stopImageStream();
    _controller?.dispose();
    _faceDetector?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kalibrasyon')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Bir cetvel veya seritmetre kullanarak telefonu yuzunuzden '
              'bilinen bir mesafede tutun, asagidaki degeri o mesafeye gore '
              'ayarlayin ve "Kalibre Et" butonuna basin.',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 24),
            Text(
              'Bilinen mesafe: ${_knownDistanceCm.toStringAsFixed(0)} cm',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            Slider(
              value: _knownDistanceCm,
              min: 15,
              max: 80,
              divisions: 65,
              label: '${_knownDistanceCm.toStringAsFixed(0)} cm',
              onChanged: (v) => setState(() => _knownDistanceCm = v),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                _status,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isReady && !_isCalibrating ? _calibrate : null,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: _isCalibrating
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Kalibre Et'),
            ),
          ],
        ),
      ),
    );
  }
}
